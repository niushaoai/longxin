from django.db import models

class Admin(models.Model):
    user = models.CharField(verbose_name="用户名", max_length=16)
    password = models.CharField(verbose_name="密码", max_length=16)
    name = models.CharField(verbose_name="姓名", max_length=16)
    gender_choices = {
        (1, "男"),
        (2, "女"),
    }
    gender = models.SmallIntegerField(
        verbose_name="性别", choices=gender_choices)

class Info(models.Model):
    temperature = models.FloatField(verbose_name="温度")
    humidity = models.FloatField(verbose_name="湿度")
    light = models.FloatField(verbose_name="光照强度")
    node = models.IntegerField(verbose_name="节点id")
    create_time = models.DateTimeField(auto_now_add=True)

class Log(models.Model):
    type_choices = {
        (1,'login'),
        (2,'warning')
    }
    type = models.SmallIntegerField(verbose_name= "日志类型" ,choices= type_choices )
    logging = models.CharField(verbose_name="日志记录",max_length= 64)
    trigger_time = models.DateTimeField(auto_now_add=True) #登录时间
    
########### 节点类####################### 
#用于记录节点的在线状态：
class Nodes(models.Model):
    type_choices = {
        (1,'在线'),
        (2,'离线')
    }
    node = models.IntegerField(verbose_name="节点id")
    type = models.SmallIntegerField(verbose_name= "节点状态" ,choices= type_choices )
    log_time = models.DateTimeField(auto_now_add=True) #登录时间

class Messages(models.Model):
    send_time = models.DateTimeField(auto_now_add = True)#最后一次发短信的事件