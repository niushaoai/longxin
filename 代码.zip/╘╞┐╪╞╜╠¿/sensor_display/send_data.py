import requests
import json

# 传感器数据
sensor_data = {
    'temperature': 30,
    'humidity': 80,
    'light':1622.442,
    'Node':1
}
# Django服务器URL
# server_url = "http://114.55.87.79:8000/sensor/data"
server_url = "http://127.0.0.1:8000/sensor/data"
# 发送数据到Django项目
print(type(sensor_data))
response = requests.post(server_url, json=json.dumps(sensor_data))
print(type(sensor_data))
# 检查响应
if response.status_code == 200:
    print("数据发送成功")
else:
    print("数据发送失败")