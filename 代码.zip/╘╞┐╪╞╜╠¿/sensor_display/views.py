from django.shortcuts import render,redirect
from sensor_display.models import Admin,Info,Log,Nodes,Messages
from django.http import JsonResponse,HttpResponse
from django.conf import settings
import os
import pandas as pd
from django.utils import timezone
import pytz
import urllib
import json
from django.views.decorators.csrf import csrf_exempt

from sensor_display.utils.aliyun import Aliyun
# Create your views here.

def login(request):
    if request.method == "GET":
        return render(request,"login.html")
    username = request.POST.get("username")
    password = request.POST.get("password")
    user = Admin.objects.filter(user = username ,password = password).first()
    if user: #如果存在
        Log.objects.create(type = 1 , logging = username + " login success "  )
        return redirect("/index")

#主页
def index(request):
    nodes = Nodes.objects.all().order_by('id')
    for item in nodes:
        seconds = timezone.now() - item.log_time
        node = item.node
        if seconds.seconds > 60 :
            Nodes.objects.filter(node = node).update(type = 2)
    nodes = Nodes.objects.all().order_by('id')
    return render(request,"index.html",{"nodes":nodes})


def info(request):

    sensor =  Info.objects.all().order_by('-id')[0:100]#获取全部数据
    return render(request,"info.html",{"sensor":sensor})

def temp(request):
    #想要实现的功能，根据不同时间，将温度进行折线图展示

    return render(request, "temp.html")

def temp_picture(request):
    info_1 = Info.objects.filter(node = '1').order_by('-id')[0:100]
    info_1 = reversed(info_1)
    info_2 = Info.objects.filter(node = '2').order_by('-id')[0:100]
    info_2 = reversed(info_2)
    info_3 = Info.objects.filter(node = '3').order_by('-id')[0:100]
    info_3 = reversed(info_3)

    info_1_temp = []
    info_2_temp = []
    info_3_temp = []
    date = []
    for item in info_1 :
        info_1_temp.append(item.temperature)
    for item in info_2 :
        info_2_temp.append(item.temperature)
    for item in info_3 :
        info_3_temp.append(item.temperature)
    for i in range(100):
        date.append(i)
    result = {
        "status": True,
        "info1":info_1_temp,
        "info2":info_2_temp,
        "info3":info_3_temp,
        "date" :date
    }
    return JsonResponse(result)

def humidity(request):

    return render(request,"humidity.html")

def humidity_picture(request):
    info_1 = Info.objects.filter(node = '1').order_by('-id')[0:100]
    info_1 = reversed(info_1)
    info_2 = Info.objects.filter(node = '2').order_by('-id')[0:100]
    info_2 = reversed(info_2)
    info_3 = Info.objects.filter(node = '3').order_by('-id')[0:100]
    info_3 = reversed(info_3)
    info_1_temp = []
    info_2_temp = []
    info_3_temp = []
    date = []
    for item in info_1 :
        info_1_temp.append(item.humidity)
    for item in info_2 :
        info_2_temp.append(item.humidity)
    for item in info_3 :
        info_3_temp.append(item.humidity)
    for i in range(100):
        date.append(i)
    result = {
        "status": True,
        "info1":info_1_temp,
        "info2":info_2_temp,
        "info3":info_3_temp,
        "date":date
    }
    return JsonResponse(result)

def light(request):
    return render(request,"light.html")

def light_picture(request):
    
    info_1 = Info.objects.filter(node = '1').order_by('-id')[0:100]
    info_1 = reversed(info_1)
    info_2 = Info.objects.filter(node = '2').order_by('-id')[0:100]
    info_2 = reversed(info_2)
    info_3 = Info.objects.filter(node = '3').order_by('-id')[0:100]
    info_3 = reversed(info_3)
    info_1_temp = []
    info_2_temp = []
    info_3_temp = []
    date = []
    for item in info_1 :
        info_1_temp.append(item.light)
    for item in info_2 :
        info_2_temp.append(item.light)
    for item in info_3 :
        info_3_temp.append(item.light)
    for i in range(100):
        date.append(i)
    result = {
        "status": True,
        "info1":info_1_temp,
        "info2":info_2_temp,
        "info3":info_3_temp,
        "date": date
    }
    return JsonResponse(result)

def log(request):
    log_info = Log.objects.all().order_by('-id')[0:10]#记录最近的十次日志
    return render(request,"log.html",{"log_info":log_info})

# def log_to_excel(request):
#     log_info = Log.objects.all().order_by('-id')
#     header = ['信息类型','日志内容','提交时间']
#     rows = [[item.type,item.logging,item.trigger_time] for item in log_info]
#     response = ExcelResponse(rows = [header] + rows)
#     response['Content-Disposition'] = 'attachment; filename=log.xlsx'

#     return response
def log_to_excel(request):
    log_info = Log.objects.all().order_by('-id')

    # 构建数据字典
    data = {
        '信息类型': [],
        '日志内容': [],
        '提交时间': [],
    }

    # 将数据库查询结果填充到数据字典中
    for obj in log_info:
        column1_value = obj.trigger_time.astimezone(pytz.UTC).replace(tzinfo=None)
        data['信息类型'].append(obj.get_type_display())
        data['日志内容'].append(obj.logging)
        data['提交时间'].append(column1_value)
        print(obj.logging)

    # 创建DataFrame
    df = pd.DataFrame(data)

    # 创建Excel文件


    # 设置响应的文件类型为Excel
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=log.xlsx'
    df.to_excel(response,index=False)
    # 将Excel文件内容写入响应

    return response

def send_message(request):

    # response = urllib.request.urlopen('http://utf8.api.smschinese.cn/?Uid=admin136&Key=3EFD3E764201B0AA0C6AF26CD366C098&smsMob=15537575065&smsText=thisisatexttry')
    # print(response.read())
    mobile = '15537575065'
    Aliyun.main(mobile)
    return redirect("/index")


#接收来自传感器的数据
@csrf_exempt 
def sensor_data(request):
    if request.method == "POST":
        data = request.body.decode("utf-8")
        json_data = json.loads(data)
        js_data = json.loads(json_data)
        temperature = js_data.get("temperature")
        humidity = js_data.get('humidity')
        light = js_data.get('light')
        node = js_data.get('Node')
        if node == 1:
            Info.objects.create(temperature=temperature,humidity=humidity,light=light,node = 1)
            Nodes.objects.filter(node = 1).update(type = 1,log_time = timezone.now())
        elif node == 2:
            Info.objects.create(temperature=temperature,humidity=humidity,light=light,node = 2)
            Nodes.objects.filter(node = 2).update(type = 1,log_time = timezone.now())
        else :
            Info.objects.create(temperature=temperature,humidity=humidity,light=light,node = 3)
            Nodes.objects.filter(node = 3).update(type = 1,log_time = timezone.now())
        send_flag = 0
        message = Messages.objects.first()
        if message:
            seconds = timezone.now() - message.send_time
            if seconds.seconds > 60 :
                send_flag = 1
        else :
            Messages.objects.create() # 如果不存在，就新创建一个
        parameter_flag = 0
        if(temperature > 35 ):
            Log.objects.create(type = 2 , logging = "Node "+ str(node ) + "  温度异常，温度为： " + str(temperature) )
            parameter_flag = 1
        if(light > 500):
            Log.objects.create(type = 2 , logging = "Node "+ str(node)  + "  光照异常，光照强度为： " + str(light) )
            parameter_flag = 1
        if(humidity > 80):
            Log.objects.create(type = 2 , logging = "Node "+ str(node)  + "  湿度异常，环境湿度为： " + str(humidity) )
            parameter_flag = 1
        if (send_flag == 1 & parameter_flag == 1  ):
            mobile = '15537575065'
            Aliyun.main(mobile)
            Messages.objects.all().update(send_time = timezone.now())
        
        return HttpResponse("数据接收成功", status=200)
    else:
        return HttpResponse("数据处理错误",status = 400)
    
