from django.apps import AppConfig


class SensorDisplayConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sensor_display'
