from PyQt5.QtWidgets import QApplication, QMainWindow, QTextEdit
from PyQt5.QtSerialPort import QSerialPort, QSerialPortInfo
from PyQt5.QtCore import QIODevice, pyqtSignal, pyqtSlot
import sys
from show import Ui_Form
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QWidget, QApplication
from PyQt5.QtWidgets import QInputDialog, QLineEdit, QDialog
import threading

import time
import random
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication
import sys, os
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import json
import urllib
import re
import threading
import requests
from plt import *

complete_data = ""
class MyApp(QObject):
    def __init__(self):
        super().__init__()
        # 创建串口对象
        self.serial_port = QSerialPort(self)
        self.serial_port.readyRead.connect(self.read_data)

        # 打开串口
        self.open_serial_port()

        # 用于存储接收到的数据片段
        self.buffer = bytearray()

    def open_serial_port(self):
        # 获取可用串口列表
        ports = QSerialPortInfo.availablePorts()

        if len(ports) > 0:
            port = ports[2]  # 获取第一个可用串口
            self.serial_port.setPort(port)
            self.serial_port.setBaudRate(QSerialPort.Baud9600)
            self.serial_port.setDataBits(QSerialPort.Data8)
            self.serial_port.setParity(QSerialPort.NoParity)
            self.serial_port.setStopBits(QSerialPort.OneStop)

            if self.serial_port.open(QIODevice.ReadOnly):
                print(f"Serial port {port.portName()} opened successfully.")
            else:
                print(f"Failed to open serial port {port.portName()}.")
        else:
            print("No available serial ports.")

    @pyqtSlot()
    def read_data(self):
        data = self.serial_port.readAll().data()
        self.buffer += data
        global complete_data
        if b'}' in self.buffer:
            index = self.buffer.index(b'}')
            complete_data = self.buffer[:index + 1]
            self.buffer = self.buffer[index + 1:]
            self.handle_data(complete_data)


    def handle_data(self, data):
        string_data=data.decode().strip()
        # Django服务器URL
        server_url = "http://114.55.87.79:8000/sensor/data"
        # 发送数据到Django项目
        sensor_data = json.loads(string_data)

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        node = sensor_data["Node"]
        humidity = sensor_data["humidity"]
        temperature =sensor_data["temperature"]
        light = sensor_data["light"]
        data = (node,humidity,temperature,light)
        cursor.execute("insert into nodes (node,humidity,temperature,light) values (?,?,?,?)",data)
        conn.commit()            
        conn.close()
        print("insert success")
        response = requests.post(server_url, json=json.dumps(sensor_data))
        # 检查响应
        if response.status_code == 200:
            print("数据发送成功")
        else:
            print("数据发送失败")

    def closeEvent(self, event):
        self.serial_port.close()
        event.accept()

# 本类用于执行一些循环、耗时的函数，并通过信号发射到UI界面
class ExQThread(QtCore.QThread):
    nodeSignal = pyqtSignal(str,str,str,str)

    def __init__(self):
        super(ExQThread, self).__init__()
        self.running = True

    def updateData(self):
        global complete_data
        if complete_data != "":
            sensor_data = json.loads(complete_data)
            node = sensor_data["Node"]
            temperature = sensor_data["temperature"]
            humidity = sensor_data["humidity"]
            light = sensor_data["light"]
            if node:
                temperature = str(temperature) + ' ℃'
                humidity = str(humidity) + ' %'
                light = str(light) + ' lux'
                node = str(node)
            self.nodeSignal.emit(node, temperature, humidity, light)

        else:
            print(22222222222222)

    def run(self):
        while self.running:
            self.updateData()
            time.sleep(1)

# 本类用于界面UI处理，主要为槽函数，接收信号。
class MyUi(QDialog, Ui_Form):
    def __init__(self):
        super(MyUi, self).__init__()
        self.setupUi(self)
    # def setupUi(self, Dialog):
    #     super(MyUi, self).setupUi(Dialog)

    # 获取传感器数值
    def updateData(self, node, temperature, humidity, light):
        if node == str(1):
            self.lineEdit_t.setText(temperature)
            self.lineEdit_h.setText(humidity)
            self.lineEdit_l.setText(light)
        if node == str(2):
            self.lineEdit_t2.setText(str(temperature))
            self.lineEdit_h2.setText(str(humidity))
            self.lineEdit_l2.setText(str(light))
        if node == str(3):
            self.lineEdit_t3.setText(str(temperature))
            self.lineEdit_h3.setText(str(humidity))
            self.lineEdit_l3.setText(str(light))
        # self.lineEdit_t.setText(temperature)

class Child1(Myplt):
    def __init__(self):
        super(Child1, self).__init__()
        # self.setupUi(self)
        # self.pushButton_4.clicked.connect(self.close)
    def getTem(self):
        self.temp()
    def getHum(self):
        self.humidity()
    def getLig(self):
        self.light()



if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    myapp = MyApp()
    child1 = Child1()
    Dialog = QDialog()
    ui = MyUi()
    ui.setupUi(Dialog)
    ui.pushButton1.clicked.connect(child1.getTem)
    ui.pushButton2.clicked.connect(child1.getHum)
    ui.pushButton3.clicked.connect(child1.getLig)
    exQthread = ExQThread()
    exQthread.nodeSignal.connect(ui.updateData)  # 信号连接槽函数
    exQthread.start()
    Dialog.show()
    sys.exit(app.exec_())

