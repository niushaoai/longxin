import sqlite3
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import matplotlib.pyplot as plt
import sys
import matplotlib.pyplot as plt

class Myplt(QObject):
    def light(self):

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()

        cursor.execute('select light from nodes where node = "1" order by id desc limit 100  ')
        rows = cursor.fetchall()
        self.x_data = []
        self.y1_data = []
        self.y2_data = []
        self.y3_data = []
        for i in range(100):
            self.x_data.append(i)
        for row in rows:
            self.y1_data.insert(0,float(row[0]))

        cursor.close()
        conn.close()

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute('select light from nodes where node = "2" order by id desc limit 100  ')
        rows = cursor.fetchall()
        for row in rows:
            self.y2_data.insert(0,float(row[0]))
        cursor.close()
        conn.close()

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute('select light from nodes where node = "3" order by id desc limit 100  ')
        rows = cursor.fetchall()
        for row in rows:
            self.y3_data.insert(0,float(row[0]))
        print('*************************')
        print(type(self.y3_data))
        print(self.y3_data)
        cursor.close()
        conn.close()

        fig,ax = plt.subplots()
        ax.plot(self.x_data,self.y1_data,label= 'node1')
        ax.plot(self.x_data,self.y2_data,label= 'node2')
        ax.plot(self.x_data,self.y3_data,label= 'node3')
        ax.set_title('light')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.legend()
        plt.show()

    def humidity(self):

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()

        cursor.execute('select humidity from nodes where node = "1" order by id desc limit 100  ')
        rows = cursor.fetchall()
        self.x_data = []
        self.y1_data = []
        self.y2_data = []
        self.y3_data = []
        for i in range(100):
            self.x_data.append(i)
        for row in rows:
            self.y1_data.insert(0,float(row[0]))

        cursor.close()
        conn.close()

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute('select humidity from nodes where node = "2" order by id desc limit 100  ')
        rows = cursor.fetchall()
        for row in rows:
            self.y2_data.insert(0,float(row[0]))
        cursor.close()
        conn.close()

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute('select humidity from nodes where node = "3" order by id desc limit 100  ')
        rows = cursor.fetchall()
        for row in rows:
            self.y3_data.insert(0,float(row[0]))
        print('*************************')
        print(type(self.y3_data))
        print(self.y3_data)
        cursor.close()
        conn.close()

        fig,ax = plt.subplots()
        ax.plot(self.x_data,self.y1_data,label= 'node1')
        ax.plot(self.x_data,self.y2_data,label= 'node2')
        ax.plot(self.x_data,self.y3_data,label= 'node3')
        ax.set_title('humidity')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.legend()
        plt.show()

    def temp(self):

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()

        cursor.execute('select temperature from nodes where node = "1" order by id desc limit 100  ')
        rows = cursor.fetchall()
        self.x_data = []
        self.y1_data = []
        self.y2_data = []
        self.y3_data = []
        for i in range(100):
            self.x_data.append(i)
        for row in rows:
            self.y1_data.insert(0,float(row[0]))

        cursor.close()
        conn.close()

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute('select temperature from nodes where node = "2" order by id desc limit 100  ')
        rows = cursor.fetchall()
        for row in rows:
            self.y2_data.insert(0,float(row[0]))
        cursor.close()
        conn.close()

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute('select temperature from nodes where node = "3" order by id desc limit 100  ')
        rows = cursor.fetchall()
        for row in rows:
            self.y3_data.insert(0,float(row[0]))
        print('*************************')
        print(type(self.y3_data))
        print(self.y3_data)
        cursor.close()
        conn.close()

        fig,ax = plt.subplots()
        ax.plot(self.x_data,self.y1_data,label= 'node1')
        ax.plot(self.x_data,self.y2_data,label= 'node2')
        ax.plot(self.x_data,self.y3_data,label= 'node3')
        ax.set_title('temperature')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.legend()
        plt.show()
# if __name__ == '__main__':
#     light()
#     temp()
#     humidity()
